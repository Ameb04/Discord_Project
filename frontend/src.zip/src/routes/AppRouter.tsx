import type { ReactNode } from "react";
import { BrowserRouter, Link, NavLink, Navigate, Route, Routes } from "react-router-dom";
import SearchResultsPage from "../pages/SearchResultsPage";
import SettingsPage from "../pages/SettingsPage";
import { LandingPage } from "../pages/LandingPage";
import { LoginPage } from "../pages/LoginPage";
import { SignupPage } from "../pages/SignupPage";
import { useAuth } from "../context/AuthContext";

function PublicOnly({ children }: { children: ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="grid min-h-screen place-items-center bg-[#090909] text-white">
        <div className="rounded-2xl border border-white/10 bg-white/[0.04] px-5 py-4 text-sm text-white/70">
          Loading...
        </div>
      </div>
    );
  }

  if (isAuthenticated) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}

function HomeRoute() {
  return <LandingPage />;
}

export function AppRouter() {
  const { isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="grid min-h-screen place-items-center bg-[#090909] text-white">
        <div className="rounded-2xl border border-white/10 bg-white/[0.04] px-5 py-4 text-sm text-white/70">
          Loading...
        </div>
      </div>
    );
  }

  return (
      <div className="min-h-screen bg-[#090909] text-white">
        <header className="flex items-center justify-between border-b border-white/10 px-6 py-4">
          <Link className="text-lg font-semibold tracking-tight text-white" to="/">
            Discord Project
          </Link>

          <nav aria-label="Main navigation" className="flex items-center gap-4 text-sm">
            <NavLink
              to="/search"
              className={({ isActive }) =>
                isActive ? "text-white" : "text-white/60 transition hover:text-white"
              }
            >
              Search
            </NavLink>
            <NavLink
              to="/settings"
              className={({ isActive }) =>
                isActive ? "text-white" : "text-white/60 transition hover:text-white"
              }
            >
              Settings
            </NavLink>
          </nav>
        </header>

        <Routes>
          <Route path="/" element={<HomeRoute />} />
          <Route
            path="/login"
            element={
              <PublicOnly>
                <LoginPage />
              </PublicOnly>
            }
          />
          <Route
            path="/signup"
            element={
              <PublicOnly>
                <SignupPage />
              </PublicOnly>
            }
          />
          <Route path="/search" element={<SearchResultsPage />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
  );
}